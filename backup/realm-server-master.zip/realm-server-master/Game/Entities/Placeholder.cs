﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RotMG.Game.Entities
{
    public class Placeholder : Entity
    {
        public Placeholder(int? lifetime = null) : base(0x070f, lifetime)
        {

        }
    }
}
