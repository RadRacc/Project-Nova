﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RotMG.Game.Logic.Loots
{
    public class TierLoot : Loot
    {
        public enum LootType
        {
            Weapon,
            Ability,
            Armor,
            Ring
        }

        public TierLoot()
        {

        }
    }
}
